import React from 'react';
import { Download } from 'lucide-react';
import { motion } from 'motion/react';

export default function FloatingDownload() {
  const handleDownload = () => {
    // We use the absolute path to the download route
    window.location.href = '/project_app.zip';
  };

  return (
    <motion.button
      id="floating-download-btn"
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
      onClick={handleDownload}
      className="fixed bottom-8 right-8 z-50 bg-emerald-600 text-white p-4 rounded-full shadow-2xl flex items-center gap-2 hover:bg-emerald-700 transition-colors group"
      title="Download Full Project Source"
    >
      <Download size={24} />
      <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-300 ease-in-out whitespace-nowrap font-medium">
        Download Project Source
      </span>
    </motion.button>
  );
}
